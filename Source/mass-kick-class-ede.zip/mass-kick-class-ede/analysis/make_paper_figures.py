#!/usr/bin/env python3
"""
Generate publication-ready figures for the v8-EFT Mass-Kick paper.
Run on VPS: source ~/v8_env/bin/activate && python3 make_paper_figures.py
"""
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import rc
import glob

# LaTeX-style fonts
rc('font', family='serif', size=12)
rc('text', usetex=False)
rc('axes', labelsize=14)
rc('xtick', labelsize=11)
rc('ytick', labelsize=11)

# Load chains
chains_raw = sorted(glob.glob('/root/v8_chains/v8_final.*.txt'))
chains = [c for c in chains_raw if 'updated' not in c and 'minimum' not in c]

all_data = []
per_chain = []
colors_chain = ['#E63946','#457B9D','#2A9D8F','#E9C46A','#F4A261','#264653']

for ci, cf in enumerate(chains):
    try:
        d = np.loadtxt(cf)
        burn = int(0.5 * len(d))
        d = d[burn:]
        per_chain.append((d, ci))
        all_data.append(d)
        print(f'Chain {ci+1}: {len(d)} samples')
    except:
        pass

data = np.concatenate(all_data)
w = data[:, 0]
print(f'Total: {len(data)} samples after burn-in')

# Column mapping (check paramnames file)
cols = {'H0': 4, 'omega_cdm': 6, 'Gamma_mk': 11, 'fEDE': 8,
        'n_s': 3, 'tau_reio': 7, 'logA': 2}

# Labels for plots
labels = {
    'H0': r'$H_0\;[\mathrm{km/s/Mpc}]$',
    'omega_cdm': r'$\omega_\mathrm{cdm}$',
    'Gamma_mk': r'$\Gamma$',
    'fEDE': r'$f_\mathrm{EDE}$',
}

def weighted_kde_2d(x, y, w, nx=80, ny=80):
    """Simple weighted 2D histogram for contours"""
    xedge = np.linspace(x.min(), x.max(), nx+1)
    yedge = np.linspace(y.min(), y.max(), ny+1)
    H, _, _ = np.histogram2d(x, y, bins=[xedge, yedge], weights=w)
    H = H.T
    # Smooth
    from scipy.ndimage import gaussian_filter
    H = gaussian_filter(H, sigma=1.5)
    # Normalize
    H = H / H.sum()
    # Find 1sigma (68%) and 2sigma (95%) levels
    Hflat = H.flatten()
    idx = np.argsort(Hflat)[::-1]
    cumsum = np.cumsum(Hflat[idx])
    levels = []
    for frac in [0.9545, 0.6827]:
        i = np.searchsorted(cumsum, frac)
        if i < len(Hflat):
            levels.append(Hflat[idx[i]])
        else:
            levels.append(Hflat[idx[-1]])
    xc = 0.5*(xedge[:-1] + xedge[1:])
    yc = 0.5*(yedge[:-1] + yedge[1:])
    return xc, yc, H, sorted(levels)

# =====================================================================
# FIGURE 1: Publication corner plot with contours
# =====================================================================
print('\nGenerating Figure 1: Corner plot...')
keys = ['H0', 'omega_cdm', 'Gamma_mk', 'fEDE']
n = len(keys)

fig, axes = plt.subplots(n, n, figsize=(10, 10))

for i in range(n):
    for j in range(n):
        ax = axes[i][j]
        if j > i:
            ax.axis('off')
            continue

        xi = data[:, cols[keys[i]]]
        
        if i == j:
            # 1D posterior
            ax.hist(xi, bins=60, weights=w, density=True,
                    color='#457B9D', alpha=0.7, edgecolor='none')
            ax.set_yticks([])
            if i == n-1:
                ax.set_xlabel(labels[keys[j]], fontsize=13)
            
            # Add reference lines
            if keys[i] == 'H0':
                ax.axvline(67.36, color='#264653', ls=':', lw=1, alpha=0.7)
                ax.axvline(73.04, color='#E63946', ls=':', lw=1, alpha=0.7)
            elif keys[i] == 'Gamma_mk':
                ax.axvline(0, color='#E63946', ls='--', lw=1.5, alpha=0.8)
        else:
            # 2D contours
            xj = data[:, cols[keys[j]]]
            try:
                xc, yc, H, levels = weighted_kde_2d(xj, xi, w)
                ax.contourf(xc, yc, H, levels=[levels[0], levels[1], H.max()],
                           colors=['#A8DADC', '#457B9D'], alpha=0.8)
                ax.contour(xc, yc, H, levels=levels,
                          colors=['#1D3557', '#1D3557'], linewidths=[0.8, 1.2])
            except:
                ax.scatter(xj[::10], xi[::10], s=0.3, alpha=0.1, c='#457B9D')

            if j == 0:
                ax.set_ylabel(labels[keys[i]], fontsize=13)
            else:
                ax.set_yticklabels([])
            if i == n-1:
                ax.set_xlabel(labels[keys[j]], fontsize=13)
            else:
                ax.set_xticklabels([])

# Add text annotation
axes[0][2].text(0.5, 0.85, r'$\Gamma = 0.062 \pm 0.043$',
               transform=axes[0][2].transAxes, fontsize=13,
               ha='center', fontweight='bold')
axes[0][2].text(0.5, 0.65, r'$P(\Gamma > 0.01) = 90\%$',
               transform=axes[0][2].transAxes, fontsize=11, ha='center')
axes[0][2].text(0.5, 0.45, r'6 chains, $R-1 \approx 0.10$',
               transform=axes[0][2].transAxes, fontsize=10, ha='center',
               color='gray')
axes[0][2].text(0.5, 0.25, f'{len(data)//1000}k samples after burn-in',
               transform=axes[0][2].transAxes, fontsize=10, ha='center',
               color='gray')

plt.subplots_adjust(hspace=0.05, wspace=0.05)
plt.savefig('fig1_corner.png', dpi=300, bbox_inches='tight')
plt.savefig('fig1_corner.pdf', bbox_inches='tight')
print('  Saved: fig1_corner.png / .pdf')

# =====================================================================
# FIGURE 2: Chain convergence diagnostic (colored by chain)
# =====================================================================
print('\nGenerating Figure 2: Chain diagnostic...')

fig, axes = plt.subplots(n, n, figsize=(11, 11))

for i in range(n):
    for j in range(n):
        ax = axes[i][j]
        if j > i:
            ax.axis('off')
            continue

        if i == j:
            for d, ci in per_chain:
                ax.hist(d[:, cols[keys[i]]], bins=40, weights=d[:, 0],
                       density=True, color=colors_chain[ci], alpha=0.35,
                       label=f'Chain {ci+1}' if i == 0 else None,
                       edgecolor='none')
            ax.set_yticks([])
            if i == 0:
                ax.legend(fontsize=7, loc='upper right', ncol=2)
            if i == n-1:
                ax.set_xlabel(labels[keys[j]], fontsize=13)
        else:
            for d, ci in per_chain:
                ax.scatter(d[::8, cols[keys[j]]], d[::8, cols[keys[i]]],
                          s=0.4, alpha=0.15, c=colors_chain[ci])
            if j == 0:
                ax.set_ylabel(labels[keys[i]], fontsize=13)
            else:
                ax.set_yticklabels([])
            if i == n-1:
                ax.set_xlabel(labels[keys[j]], fontsize=13)
            else:
                ax.set_xticklabels([])

plt.suptitle('Chain convergence diagnostic: all 6 chains overlap',
            fontsize=13, y=0.98)
plt.subplots_adjust(hspace=0.05, wspace=0.05)
plt.savefig('fig2_chains.png', dpi=300, bbox_inches='tight')
plt.savefig('fig2_chains.pdf', bbox_inches='tight')
print('  Saved: fig2_chains.png / .pdf')

# =====================================================================
# FIGURE 3 (bonus): Gamma posterior with physics annotations
# =====================================================================
print('\nGenerating Figure 3: Gamma posterior...')

fig, ax = plt.subplots(figsize=(8, 5))
gamma = data[:, cols['Gamma_mk']]

ax.hist(gamma, bins=80, weights=w, density=True,
       color='#457B9D', alpha=0.7, edgecolor='none')
ax.axvline(0, color='#E63946', ls='--', lw=2, label=r'$\Gamma = 0$ ($\Lambda$CDM)')

# Mean and 95% UL
gmean = np.average(gamma, weights=w)
ax.axvline(gmean, color='#E9C46A', ls='-', lw=2,
          label=f'Mean = {gmean:.3f}')

# 95% upper limit
idx = np.argsort(gamma)
cumw = np.cumsum(w[idx]) / np.sum(w)
g95 = gamma[idx][np.searchsorted(cumw, 0.95)]
ax.axvline(g95, color='#2A9D8F', ls=':', lw=2,
          label=f'95% UL = {g95:.3f}')

# Shade P(Gamma > 0.01)
mask = gamma > 0.01
frac = np.sum(w[mask]) / np.sum(w)
ax.fill_betweenx([0, ax.get_ylim()[1]*0.3], 0.01, 0.15,
                alpha=0.1, color='#2A9D8F')
ax.text(0.08, ax.get_ylim()[1]*0.85 if ax.get_ylim()[1] > 0 else 5,
       f'$P(\\Gamma > 0.01) = {frac*100:.0f}\\%$',
       fontsize=13, color='#264653')

ax.set_xlabel(r'$\Gamma$ (Mass-Kick coupling)', fontsize=14)
ax.set_ylabel('Posterior density', fontsize=14)
ax.set_xlim(-0.005, 0.155)
ax.legend(fontsize=11, loc='upper right')
ax.set_title('Mass-Kick posterior: Planck + BAO + SH0ES', fontsize=13)

plt.tight_layout()
plt.savefig('fig3_gamma_posterior.png', dpi=300, bbox_inches='tight')
plt.savefig('fig3_gamma_posterior.pdf', bbox_inches='tight')
print('  Saved: fig3_gamma_posterior.png / .pdf')

# =====================================================================
# Summary statistics
# =====================================================================
print('\n' + '='*60)
print('  FINAL RESULTS SUMMARY')
print('='*60)
for name in ['H0', 'omega_cdm', 'Gamma_mk', 'fEDE', 'n_s', 'tau_reio']:
    v = data[:, cols[name]]
    m = np.average(v, weights=w)
    s = np.sqrt(np.average((v-m)**2, weights=w))
    print(f'  {name:>12s} = {m:.4f} +/- {s:.4f}')

print(f'\n  P(Gamma > 0.01) = {np.sum(w[gamma>0.01])/np.sum(w)*100:.1f}%')
print(f'  P(Gamma > 0.03) = {np.sum(w[gamma>0.03])/np.sum(w)*100:.1f}%')
print(f'  95% UL: Gamma < {g95:.4f}')

best = np.argmin(data[:, 1])
print(f'\n  Best-fit -logL = {data[best,1]:.2f}')
print(f'  Best-fit: H0={data[best,4]:.1f}, Gamma={data[best,11]:.3f}, fEDE={data[best,8]:.3f}')
print('='*60)
print('  Files: fig1_corner.pdf, fig2_chains.pdf, fig3_gamma_posterior.pdf')
print('='*60)
