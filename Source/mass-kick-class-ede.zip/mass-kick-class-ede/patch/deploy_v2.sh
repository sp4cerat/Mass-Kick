#!/bin/bash
# =============================================================================
# v8-EFT Stufe-1 Fix: Deploy corrected patch to VPS
#
# FIXES:
# 1. Background A²(chi) = 1+(Gamma/2)cos(theta) -- was 1+Gamma*cos (BUG!)
# 2. Smooth floor instead of hard m2_ratio < 0.01 cutoff
# 3. All three perturbation blocks use identical A²(chi) definition
# 4. Conservative MCMC priors (neutral start, tighter Gamma range)
# 5. ignore_obsolete: true for Cobaya version check
#
# USAGE: scp this + v8_mass_kick_v2.patch + YAMLs to VPS, then run
# =============================================================================
set -e
source ~/v8_env/bin/activate
export COBAYA_PACKAGES_PATH=~/cobaya_packages

echo "=================================================="
echo "  v8-EFT Stufe-1: Deploy fixed patch"
echo "=================================================="

# Stop any running MCMC
echo "[1/6] Stopping old MCMC..."
pkill -f cobaya 2>/dev/null || true
sleep 2

# Apply fixed patch
echo "[2/6] Applying v2 patch..."
cd ~/class_ede
git checkout -- source/background.c source/perturbations.c source/input.c include/background.h
git apply ~/v8_pipeline/v8_mass_kick_v2.patch
echo "  ✓ Patch applied"

# Rebuild
echo "[3/6] Rebuilding CLASS..."
make clean 2>/dev/null || true
make -j$(nproc) libclass.a 2>&1 | tail -1
make -j$(nproc) class 2>&1 | tail -1
echo "  ✓ CLASS compiled"

# Rebuild Python wrapper
echo "[4/6] Rebuilding classy..."
cd python
rm -f classy.c *.so
rm -rf build
cython classy.pyx 2>/dev/null
sed -i '/#include.*".*class\.h"/i #undef I' classy.c 2>/dev/null
sed -i '/#include.*".*common\.h"/i #undef I' classy.c 2>/dev/null
if ! grep -q "^#undef I" classy.c; then
    sed -i '/#include.*arrayobject\.h/a #undef I' classy.c
fi

PYINC=$(python -c "import sysconfig; print(sysconfig.get_path('include'))")
NPINC=$(python -c "import numpy; print(numpy.get_include())")
SUFFIX=$(python3-config --extension-suffix)

gcc -shared -fPIC -O3 -fopenmp \
    -I${PYINC} -I${NPINC} \
    -I../include -I../external/RecfastCLASS \
    -I../external/heating -I../external/HyRec2020 \
    -DHYREC -D__CLASSDIR__=\"/root/class_ede\" \
    classy.c \
    -L.. -lclass -lgsl -lgslcblas -lfftw3 -lm -fopenmp \
    -o classy${SUFFIX} 2>&1 | tail -2

mkdir -p build/lib.linux-x86_64-cpython-312
cp classy${SUFFIX} build/lib.linux-x86_64-cpython-312/
cd ..
mkdir -p build
cp -r python/build/lib.* build/
echo "  ✓ classy rebuilt"

# Copy YAMLs
echo "[5/6] Installing configs..."
cp ~/v8_pipeline/v8_mcmc_v2.yaml ~/v8_pipeline/ 2>/dev/null || true
cp ~/v8_pipeline/v8_test_v2.yaml ~/v8_pipeline/ 2>/dev/null || true

# Quick verification
echo "[6/6] Verification..."
cd ~/v8_pipeline

python3 -c "
import sys, glob
for p in glob.glob('/root/class_ede/python/build/lib.*'):
    sys.path.insert(0, p)
sys.path.insert(0, '/root/class_ede/python')
from classy import Class
c = Class()
c.set({
    'output': 'tCl,mPk', 'l_max_scalars': 2500, 'P_k_max_1/Mpc': 3.0,
    'omega_b': 0.02237, 'omega_cdm': 0.12, 'h': 0.69,
    'A_s': 2.1e-9, 'n_s': 0.97, 'tau_reio': 0.065,
    'N_ur': 2.0328, 'N_ncdm': 1, 'm_ncdm': 0.06,
    'Omega_Lambda': 0, 'Omega_fld': 0, 'Omega_scf': -1,
    'fEDE': 0.05, 'log10z_c': 3.562, 'thetai_scf': 2.83,
    'n_scf': 3, 'CC_scf': 1, 'scf_tuning_index': 3,
    'scf_parameters': '1, 1, 1, 1, 1, 0.0',
    'attractor_ic_scf': 'no',
    'Gamma_mk': 0.05, 'f_phi_mk': 0.20,
})
c.compute()
print(f'  sigma8 = {c.sigma8():.4f}  H0 = {c.Hubble(0)*2997.92458:.1f}')
print(f'  ✓ v2 patch working')
c.struct_cleanup(); c.empty()

# Null test
c2 = Class()
c2.set({
    'output': 'tCl,mPk', 'l_max_scalars': 2500, 'P_k_max_1/Mpc': 3.0,
    'omega_b': 0.02237, 'omega_cdm': 0.12, 'h': 0.69,
    'A_s': 2.1e-9, 'n_s': 0.97, 'tau_reio': 0.065,
    'N_ur': 2.0328, 'N_ncdm': 1, 'm_ncdm': 0.06,
    'Omega_Lambda': 0, 'Omega_fld': 0, 'Omega_scf': -1,
    'fEDE': 0.05, 'log10z_c': 3.562, 'thetai_scf': 2.83,
    'n_scf': 3, 'CC_scf': 1, 'scf_tuning_index': 3,
    'scf_parameters': '1, 1, 1, 1, 1, 0.0',
    'attractor_ic_scf': 'no',
    'Gamma_mk': 0.0, 'f_phi_mk': 0.0,
})
c2.compute()
print(f'  baseline = {c2.sigma8():.4f}  (Gamma=0)')
print(f'  ✓ Null test passed')
c2.struct_cleanup(); c2.empty()
" 2>&1

echo ""
echo "=================================================="
echo "  ✓ v2 patch deployed. Start MCMC:"
echo ""
echo "  # Quick test first:"
echo "  cobaya-run v8_test_v2.yaml -f"
echo ""
echo "  # Full MCMC:"
echo "  nohup cobaya-run v8_mcmc_v2.yaml -f > mcmc_v2_log.txt 2>&1 &"
echo "=================================================="
